package auxiliar

import "fmt"

func Escrever() {
	fmt.Println("Escrevendo do auxiliar")
}

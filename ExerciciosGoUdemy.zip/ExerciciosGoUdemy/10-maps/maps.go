package main

import "fmt"

//Pense em um dicionário, você tem palavras e suas definições associadas
// Quando você procura uma palavra, você obtém sua definição.

func main() {
	fmt.Println("maps")
	usuario := map[string]string{ // dentro tipo das chaves, fora tipo dos valores
		// usuario :=    [tipoDaChave]tipoValor
		"nome":      "jhona",
		"sobrenome": "godoy",
	}
	fmt.Println(usuario["nome"], "print 1") // aqui vai imprimir só o nome, por que eu pedi a string "nome"
	// e ele me retornou o significado/valor dela

	usuario2 := map[string]map[string]string{
		"nome": {
			"primeiro": "jhonata",
			"ultimo":   "Cabitza",
		},
		"Curso": {
			"nome":   "Jhona",
			"campus": "Impacta",
		},
	}
	fmt.Println(usuario2, "print 2") // aqui me printa o usuario, nome e curso

	usuario2["signo"] = map[string]string{
		"nome": "gemeos",
	}
	fmt.Println(usuario2, "print 3") // aqui está adicionando/contatenando um map de signo
}

package main

import "fmt"

func main() {
	fmt.Println("Estruturas de controle") // Comandos que controlam fluxo de execução em programas Go.
	//como >if e else< >for< >tipos de for< >tipos de if<

	numero := 10

	if numero > 15 {
		fmt.Println("Maior que 15")
	} else {
		fmt.Println("Menor ou igual que 15")
	}

	if outronumero := numero; outronumero > 0 { // Cria a var dentro da condicao. >>>>if init<<<<
		fmt.Println("Numero é maior que 0") // variavel só existe dentro dessa condição
	} else if numero < -10 {
		fmt.Println("Numero é menor que -10")
	} else {
		fmt.Println("Entre 0 e -10")
	}
}

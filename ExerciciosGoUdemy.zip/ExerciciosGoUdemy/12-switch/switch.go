package main

import "fmt"

//quando tem muitas condicoes para ser avaliada, mais facil para mexer e fica mais limpo o codigo
// É como uma caixa de seleção com várias opções, e você pode fazer a condição com base na opção selecionada

func diaDaSemana(numero int) string {
	switch numero {
	case 1:
		return "domingo"
	case 2:
		return "segunda feira"
	case 3:
		return "terça feira"
	case 4:
		return "quarta feira"
	case 5:
		return "quinta feira"
	case 6:
		return "sexta feira"
	case 7:
		return "sabado feira"

	default:
		return "Numero inválido"
	}

}

func diaDaSemana2(numero int) string {
	var diaDaSemana string

	switch {
	case numero == 1:
		diaDaSemana = "domingo"
	case numero == 2:
		diaDaSemana = "segunda feira"
	case numero == 3:
		diaDaSemana = "terça feira"
	case numero == 4:
		diaDaSemana = "quarta feira"
	case numero == 5:
		diaDaSemana = "quinta feira"
	case numero == 6:
		diaDaSemana = "sexta feira"
	case numero == 7:
		diaDaSemana = "sabado"
	default:
		diaDaSemana = "numero invalido"
	}
	return diaDaSemana
}

func main() {
	fmt.Println("switch")

	dia := diaDaSemana(8)
	fmt.Println(dia)

	fmt.Println("- - - - - - - - - - - - - -")

	dia2 := diaDaSemana2(2)
	fmt.Println(dia2)
}

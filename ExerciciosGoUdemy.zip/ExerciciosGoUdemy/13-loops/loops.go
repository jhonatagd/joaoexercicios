package main

import (
	"fmt"
	"time"
)

// for, unico meio de fazer loop em go
func main() {
	i := 0

	for i < 3 {
		i++
		fmt.Println("Incrementando i: ", i)
		time.Sleep(time.Second) // para nao ficar muito rapido sair contanto coisa a doidado
	}

	for j := 0; j < 3; j++ { // aqui cria a variavel j, e le assim "cria a variavel j, se j for menor que 10, j + 1"
		fmt.Println("incrementando j: ", j)
		time.Sleep(time.Second)
	}
}

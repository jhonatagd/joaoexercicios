package main

import "fmt"

//Uma função que especifica os nomes das variáveis de retorno.
//Os valores de retorno podem ser acessados >>diretamente por seus nomes<<< ao chamar a função

func soma(numeros ...int) int { // >>...<< de um a N numeros
	total := 0
	for _, numero := range numeros {
		total += numero
	}
	return total // aqui é um exemplo
}

func escrever(texto string, numeros ...int) {
	for _, numero := range numeros {
		fmt.Println(texto, numero)
	}
}

func main() {
	totalDaSoma := soma(1, 2, 3, 4, 0)
	fmt.Println(totalDaSoma)

	escrever("Ola mundo", 10, 23, 12, 2, 4)
}

package main

import "fmt"

//Uma função que não possui um nome explicitamente definido
//Também chamada de função lambda ou >>>>função sem nome<<<<
//Pode ser passada como argumento para outras funções ou atribuída a uma variável.

func main() {

	func(texto string) {
		fmt.Println(texto)
	}("passando parametro") // "()" declarando para o go que é uma funçao anonima
	// assim que declarar já executa

	retorno := func(texto string) string {
		return fmt.Sprintf("recebido -> %s", texto)
	}("teste")

	fmt.Println(retorno)
}

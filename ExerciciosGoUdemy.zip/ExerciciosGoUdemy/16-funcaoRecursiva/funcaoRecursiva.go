package main

import "fmt"

func fibonacci(posicao uint) uint { // funcoes que chamam ela mesma, depende de outra execucao dela mesmo
	if posicao <= 1 {
		return posicao
	}
	return fibonacci(posicao-2) + fibonacci(posicao-1) // aqui chama ela mesmo<<<
}

//Uma função que se chama a si mesma durante sua execução.
//É útil para resolver problemas que podem ser subdivididos em subproblemas menores e repetidos.

func main() {
	fmt.Println("funcoes recursivas")
	// 1 1 2 3 5 8 13
	posicao := uint(6)
	fmt.Println(fibonacci(posicao))
}

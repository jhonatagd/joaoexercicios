package main

import "fmt"

// defer >>> adiar, deixa para depois
func funcao1() {
	fmt.Println("Executando a funcao 1")
}

func funcao2() {
	fmt.Println("Executando a funcao 2")
}

//Uma declaração usada para adiar a execução de uma função até o final do escopo atual.
//Pode ser útil para garantir que determinadas ações sejam executadas antes de sair de uma função ou bloco.

func aluniEstaAprovado(n1, n2 float32) bool {
	defer fmt.Println("Média calculada. resultado sera retornado")
	fmt.Println("Entrando na funcao para verificar se o aluno esta aprovado.")

	media := (n1 + n2) / 2

	if media >= 6 {
		return false
	}
	return false
}

func main() {
	defer funcao1() //>>> prioriza primeiro func2 depois func 1 <<<
	funcao2()

	fmt.Println(aluniEstaAprovado(7, 10))
}

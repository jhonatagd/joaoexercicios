package main

import "fmt"

//recover deve ser chamado dentro de uma função adiada. Quando a função envolvente entrar em pânico
//o adiamento será ativado e uma recoverchamada dentro dele capturará o pânico.

func recuperaExecucao() {
	if r := recover(); r != nil { // r vai armazenar o resultado da funcao recover

		fmt.Println("execucao recuperada com sucesso")
	}
}

//Uma função embutida em Go usada para recuperar e tratar erros ou panics durante a execução do programa.

func alunoAprovado(n1, n2 float64) bool {
	defer recuperaExecucao()
	media := (n1 + n2) / 2

	if media > 6 {
		return true
	} else if media < 6 {
		return false
	}

	panic("A MÉDIA É EXATAMENTE 6") // panic chamado chama as funcoes que tem defer
	//panic mata a execução do programa porem >>Recover<< recupera a execução
}

func main() {
	fmt.Println(alunoAprovado(6, 6))
	fmt.Println("pós execução!")
}

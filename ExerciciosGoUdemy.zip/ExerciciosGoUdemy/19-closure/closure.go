package main

import "fmt"

//closure sao funcoes que referenciam variaveis que estao fora do seu corpo

func closure() func() {
	texto := "dentro da funcao closure"
	funcao := func() {
		fmt.Println(texto)

	}

	return funcao
}

//>>Função<< que captura variáveis do escopo externo

func main() {
	texto := "dentro da funcao main"
	fmt.Println(texto)

	funcaoNova := closure() // recebe func de closure, que printa o texto
	funcaoNova()
}

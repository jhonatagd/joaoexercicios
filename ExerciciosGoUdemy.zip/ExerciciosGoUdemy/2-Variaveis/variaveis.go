package main

import "fmt"

var variavel7 string
var variavel1 string = "1" //var na frente> global
func main() {
	variavel2 := "2"
	fmt.Println(variavel1, variavel2)

	var (
		variavel3 string = "teste"
		variavel4 string = "teste"
	)
	fmt.Println(variavel3, variavel4)

	variavel5, variavel6 := "5", "6"
	fmt.Println(variavel5, variavel6)

	var variavel7 string
	variavel7 = "7"
	fmt.Println(variavel7)
}

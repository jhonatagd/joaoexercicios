package main

import "fmt"

//Permite manipular diretamente os >>valores de uma variável<< em >vez de uma cópia dela<

func inverterSinais(numero int) int {
	return numero * -1
}

func inverterSinalComPonteiro(numero *int) {
	*numero = *numero * -1
}

func main() {
	numero := 20
	numeroInvertido := inverterSinais(numero)
	fmt.Println(numeroInvertido)
	fmt.Println(numero)

	novoNumero := 34
	fmt.Println(novoNumero)
	inverterSinalComPonteiro(&novoNumero)
	fmt.Println(novoNumero)
}

package main

import "fmt"

//func que é executada antes da main
//Uma função especial em Go que é executada automaticamente no momento da >>inicialização de um pacote<<

func main() {
	fmt.Println("funcao main sendo executada")
}

func init() {
	fmt.Println("funcao init sendo executada")
}

package main

import "fmt"

//Funções associadas a tipos de dados definidos pelo usuário
//Permitem que um tipo tenha comportamentos específicos associados a ele.

type usuario struct { //uma estrutura
	nome  string
	idade int
}

//>métodos Go são semelhantes à função< com uma diferença, o método contém um >>>argumento receptor<<<

func (u usuario) salvar() { // u variavel para usar para >>referenciar<< outros campos do usuario que chamou o metodo
	fmt.Println("dentro do metodo salvar")
}

func (u usuario) maiorIdade() bool { //metodo tem como recepcao uma struct
	return u.idade >= 18
}

func main() {
	usuario1 := usuario{"jhonata", 18}
	fmt.Println(usuario1)
	usuario1.salvar() // Aqui chama o metodo/func salvar

	usuario2 := usuario{"Marquito", 54}
	usuario2.salvar()
	fmt.Println(usuario2)
}

package app

import (
	"fmt"
	"github.com/urfave/cli"
	"log"
	"net"
) //Referencia o pacote pelo o que vem na ultima barra

// Gerar vai retornar a aplicacao da linha de comando pronta para ser executada
func Gerar() *cli.App {
	app := cli.NewApp()
	app.Name = "aplicacao de linha de comando"              // nome da aplicacao
	app.Usage = "Busca IPs e nomes de servidor na internet" // utilizacao da aplicacao

	flags := []cli.Flag{ //parametro que vamos passar para funcionar
		cli.StringFlag{
			Name:  "host",
			Value: "devboock.com.br",
		},
	}

	app.Commands = []cli.Command{ //slice de comandos para a aplicacao executar
		{
			Name:   "Ip",
			Usage:  "Busca IPs de endereço na internet",
			Flags:  flags,
			Action: buscarIps,
		},
		{
			Name:   "servidores",
			Usage:  "Busca nome dos servidores na internet",
			Flags:  flags,
			Action: buscarServidores},
	}
	return app
}

func buscarServidores(c *cli.Context) {
	host := c.String("host")

	servidores, erro := net.LookupNS(host) // name server
	if erro != nil {
		log.Fatal(erro)
	}

	for _, servidore := range servidores {
		fmt.Println(servidore)
	}
}

func buscarIps(c *cli.Context) {
	host := c.String("host") //retorna o valor da flag host ali em cima e joga nessa variavel

	ips, erro := net.LookupIP(host) // aqui busca os ip, retorna um slice de ip e um erro
	if erro != nil {
		log.Fatal(erro)
	}

	for _, ip := range ips {
		fmt.Println(ip)
	}

}

package main

import (
	"fmt"
	"linha-de-comando/app"
	"log"
	"os"
)

func main() {
	fmt.Println("ponto de partida")
	aplicacao := app.Gerar() //nossa func ali do app
	if erro := aplicacao.Run(os.Args); erro != nil {
		log.Fatal(erro) // faz parar a aplicacao
	} // para rodar na linha de comando

}

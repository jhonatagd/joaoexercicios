package main

import (
	"fmt"
	"time"
)

//PARALELISMO duas ou mais tarefas executandas exatamente ao mesmo tempo

func main() {
	go Escrever("Ola mundo") //goroutine - nem comeca a linha 11 e ja vai para a 12
	Escrever("Programando em Go")
}

func Escrever(texto string) {
	for {
		fmt.Println(texto)
		time.Sleep(time.Second)
	}
}

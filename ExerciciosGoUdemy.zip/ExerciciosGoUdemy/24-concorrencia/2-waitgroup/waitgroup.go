package main

import (
	"fmt"
	"sync"
	"time"
)

func main() {
	var waitGroup sync.WaitGroup

	waitGroup.Add(2) // 2 gorutines esperar terminar

	go func() {
		Escrever("ola mundo")
		waitGroup.Done() // -1
	}()

	go func() {
		Escrever("Programando em Go")
		waitGroup.Done() //-1
	}()

	waitGroup.Wait() // espera waitGroup.Add chegar em 0
}

func Escrever(texto string) {
	for i := 0; i < 5; i++ {
		fmt.Println(texto)
		time.Sleep(time.Second)
	}
}

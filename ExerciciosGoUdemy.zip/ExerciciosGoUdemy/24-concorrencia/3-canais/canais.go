package main

import (
	"fmt"
	"time"
)

// canal de comunicacao pode tanto enviar como receber, sincrozina as goroutines
// <- enviando / -> Recebendo
func main() {
	canal := make(chan string)
	go Escrever("ola mundo", canal)
	fmt.Println("depois funcao escrever comeca a ser executada")

	for mensagem := range canal { // le as mensagens abertas, fechando ele encerra o programa
		fmt.Println(mensagem)
	}
	fmt.Println("Fim do programa")
}

//deadlook - problema quando está esperando uma coisa que nunca vai acontecer

func Escrever(texto string, canal chan string) {
	time.Sleep(time.Second * 5)
	for i := 0; i < 5; i++ {
		canal <- texto //enviar o valor de texto para o canal
		time.Sleep(time.Second)
	}
	close(canal) // nao vai enviar nem receber mais
}

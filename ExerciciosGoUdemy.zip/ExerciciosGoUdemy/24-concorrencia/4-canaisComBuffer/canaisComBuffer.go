package main

import "fmt"

// canal com buffer é o canal que limita a capacidade
func main() {
	canal := make(chan string, 2) // canal com capacidade 2
	canal <- "ola mundo"
	canal <- "Programando em go" // enviando 2 e recebendo 1

	mensagem := <-canal // recebendo
	fmt.Println(mensagem)
}

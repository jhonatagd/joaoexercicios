package main

import (
	"fmt"
	"time"
)

func main() {
	canal1, canal2 := make(chan string), make(chan string)

	go func() {
		for {
			time.Sleep(time.Millisecond * 500) // meio segundo
			canal1 <- "Canal 1"
		}
	}()

	go func() {
		for {
			time.Sleep(time.Second * 2) // 2 segundos
			canal2 <- "Canal 2"
		}
	}()

	for {
		select { //para fazer consultas
		case mensagemCanal1 := <-canal1: // caso canal1 esteja pronto para receber o valor, printa na tela
			fmt.Println(mensagemCanal1)
		case mensagemCanal2 := <-canal2:
			fmt.Println(mensagemCanal2)

		}
	}

}

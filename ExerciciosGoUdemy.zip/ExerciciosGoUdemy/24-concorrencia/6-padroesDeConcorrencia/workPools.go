package main

import "fmt"

// distribuir tarefas em várias unidades de processamento de forma paralela e eficiente.
// work pools deixa um pouco mais rapido o processo
func main() {
	tarefas := make(chan int, 45) //criando canal
	resultados := make(chan int, 45)

	go worker(tarefas, resultados)
	//go worker(tarefas, resultados)
	//go worker(tarefas, resultados)
	//go worker(tarefas, resultados)
	//go worker(tarefas, resultados)

	for i := 0; i < 45; i++ {
		tarefas <- i
	}
	close(tarefas)

	for i := 0; i < 45; i++ {
		resultado := <-resultados
		fmt.Println(resultado)
	}

}

func worker(tarefas <-chan int, resultados chan<- int) { // tarefa recebe dados, resultados envia dados
	for nuemro := range tarefas {
		resultados <- fibonacci(nuemro)
	} //para cada tarefa que tiver no range, jogar um valor em resultado, valor fibonacci
}

func fibonacci(posicao int) int {
	if posicao <= 1 {
		return posicao
	}
	return fibonacci(posicao-2) + fibonacci(posicao-1)
}

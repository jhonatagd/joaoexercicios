package main

import (
	"fmt"
	"time"
)

// produz valores sequenciais sob demanda, economizando memória e recursos.
// Generator, funcao que encapsula chamada para goroutines e devolve um canal
func main() {
	canal := escrever("ola mundo")

	for i := 0; i < 10; i++ {
		fmt.Println(<-canal)
	}
}

// encapsula// esconder complexidade da goroutines
func escrever(texto string) <-chan string {
	canal := make(chan string)

	go func() {
		for {
			canal <- fmt.Sprintf("Valor recebido: %s", texto)
			time.Sleep(time.Millisecond * 500) //meio segundo
		}
	}()

	return canal
}

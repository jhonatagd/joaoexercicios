package main

import (
	"fmt"
	"time"
)

// combina múltiplas entradas em uma única saída, útil em comunicação e processamento de dados.
func main() {
	canal := multiplexar(escrever("ola mundo"), escrever("programando em go"))

	for i := 0; i < 10; i++ {
		fmt.Println(<-canal)
	}
}

func multiplexar(canalDeEntrada1, canalDeEntrada2 <-chan string) <-chan string {
	canalDeSaida := make(chan string)

	go func() {
		for {
			select {
			case mensagem := <-canalDeEntrada1: //caso tenha mensagem disponivel no canal1,
				canalDeSaida <- mensagem // joga no canal de saida a mensagem
			case mensagem := <-canalDeEntrada2:
				canalDeSaida <- mensagem
			}
		}
	}()
	return canalDeSaida
}

func escrever(texto string) <-chan string {
	canal := make(chan string)

	go func() {
		for {
			canal <- fmt.Sprintf("Valor recebido: %s", texto)
			time.Sleep(time.Millisecond * 500) //meio segundo
		}
	}()

	return canal
}

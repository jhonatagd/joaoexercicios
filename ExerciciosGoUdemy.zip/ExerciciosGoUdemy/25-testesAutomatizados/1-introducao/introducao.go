package main

import (
	enderecos "1-introducao/2-enderecos"
	"fmt"
)

func main() {
	tipoEndereco := enderecos.TipoDeEndereco("Rua Paulista")
	fmt.Println(tipoEndereco)
}

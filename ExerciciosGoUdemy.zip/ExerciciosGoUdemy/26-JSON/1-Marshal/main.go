package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
)

type cachorro struct {
	Nome  string `json:"nome"` // nome é a chave
	Raca  string `json:"raca"`
	Idade uint   `json:"idade"`
}

func main() {
	c := cachorro{"Rex", "Dalmata", 3}
	fmt.Println(c)

	//converter para json
	cachoroEmJSON, erro := json.Marshal(c)
	if erro != nil {
		log.Fatal(erro)
	}
	fmt.Println(cachoroEmJSON)
	fmt.Println(bytes.NewBuffer(cachoroEmJSON)) // vai dar a saida em json

	c2 := map[string]string{
		"nome": "Toby",
		"Raca": "Pincher",
	}
	cachoro2EmJSON, erro := json.Marshal(c2)
	if erro != nil {
		log.Fatal(erro)
	}
	fmt.Println(cachoro2EmJSON)
	fmt.Println(bytes.NewBuffer(cachoro2EmJSON))
}

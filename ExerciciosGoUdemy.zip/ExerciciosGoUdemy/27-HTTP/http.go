package main

import (
	"log"
	"net/http"
)

// HTTP é um protocolo de comunicacao / base da comunicacao web
// cliente > faz requisição < e servidor > processa requisição e envia uma resposta < //request e response <<<<
// GET(buscar) POST(cadastrar) PUT(atualizar) DELETE(deletar)
func main() {
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("Pagina raiz")) // aqui escreve a mensagem de byte
	})

	http.HandleFunc("/home", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("Ola mundo"))
	})

	http.HandleFunc("/usuarios", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("carregar paginas de usuarios"))
	})

	log.Fatal(http.ListenAndServe(":8080", nil))
}

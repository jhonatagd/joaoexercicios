package main

import (
	"fmt"
	"html/template"
	"log"
	"net/http"
)

var templates *template.Template //vamos usar para pegar os Templates/modelos

type usuario struct {
	Nome  string
	Email string
}

func main() {
	templates = template.Must(template.ParseGlob("/Users/jhgodoy/exercicios:estudos/ExerciciosGoUdemy/28-HTML/home.html")) //padrao de arquivo para referenciar todos .html

	http.HandleFunc("/home", func(w http.ResponseWriter, r *http.Request) {

		u := usuario{"Joao", "joaotetete@gmail.com"}

		templates.ExecuteTemplate(w, "home.html", u) //executar o template especifico
	})

	fmt.Println("Escutando na porta 8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}

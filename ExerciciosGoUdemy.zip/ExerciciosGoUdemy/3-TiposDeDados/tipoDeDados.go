package main

import "fmt"

// 1 byte pode ser usado para representar !!256!! caracteres
func main() {
	var numero int64 = 1000000000000000 //(8 bytes)
	fmt.Println(numero)

	var numero2 uint32 = 10000 // *uint32* igual a *rune* / (4 bytes)
	fmt.Println(numero2)

	var numero3 byte = 123 // *byte* igual a *int8* / (1 byte)
	fmt.Println(numero3)

	var numeroFloat float64 = 100000000.45 //(8 bytes)
	fmt.Println(numeroFloat)

	var numeroFloat2 float32 = 1000.45 //(4 bytes)
	fmt.Println(numeroFloat2)
}

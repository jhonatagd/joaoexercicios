package main

import (
	servidor "crud/2-Servidor"
	"fmt"
	"github.com/gorilla/mux"
	"log"
	"net/http"
)

// Create> Read > Update > Delete >>>>CRUD<<<<<
func main() {

	router := mux.NewRouter() //as portas
	router.HandleFunc("/usuarios", servidor.CriarUsuario).Methods(http.MethodPost)
	fmt.Println("executando na porta 8083")
	log.Fatal(http.ListenAndServe(":8083", router))

}

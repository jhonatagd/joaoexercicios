package main

import "fmt"

func somar(n1 int8, n2 int8) int8 {
	return n1 + n2
}

// Pode ter mais de um retorno por função
func calculos(n1, n2 int8) (int8, int8) { // func com mais de um retorno
	soma := n1 + n2
	subtracao := n1 - n2
	return soma, subtracao // aqui retorna os dois int8
}

func main() {
	soma := somar(10, 20)
	fmt.Println(soma)

	var f = func(txt string) string { // (parametro) retorno lambda
		fmt.Println("teste")
		return txt
	}

	var resultado string
	resultado = f("Texto da funcao f")
	fmt.Println(resultado)

	// >> _ << ignora como:
	//resultadoSoma, _ := calculos(10, 15)
	resultadoSoma, resultadoSubtracao := calculos(10, 15)
	fmt.Println(resultadoSoma, resultadoSubtracao)
}

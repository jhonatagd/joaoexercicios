package main

import "fmt"

func main() {
	//Aritmeticos
	soma := 1 + 2
	subtracao := 1 - 2
	divisao := 10 / 4
	multiplicacao := 10 * 5
	restoDivisao := 10 % 2
	fmt.Println(soma, subtracao, divisao, multiplicacao, restoDivisao)

	// go é muito tipado ( doido pelos tipos, tem que ser certinho) / nao deixa misturar como tipo x com tipo y
	var numero1 int16 = 20
	var numero2 int16 = 40
	somaNumeros := numero1 + numero2
	fmt.Println(somaNumeros)

	//Atribuição
	var variavel1 string = "string"
	variavel2 := "string2" //marmota
	fmt.Println(variavel1, variavel2)

	//Operadores relacionais
	fmt.Println(1 > 2)
	fmt.Println(1 >= 2)
	fmt.Println(1 <= 2)
	fmt.Println(1 < 2)
	fmt.Println(1 == 2)
	fmt.Println(1 != 2)

	//OPERADORES LOGICOS SÓ TEM 3 / && "e" / || "ou" / ! "nega"
	verdadeiro, falso := true, false
	fmt.Println(verdadeiro && falso)
	fmt.Println(verdadeiro || falso)
	fmt.Println(!verdadeiro)

	// operadores unarios
	numero := 20
	numero++     //21
	numero += 15 // numero = numero + 15 // 35

	numero = 10
	numero--
	numero -= 15 // numero = numero + 15
}

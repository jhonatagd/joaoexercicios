package main

import "fmt"

//Mais perto que Go tem de clases/ uma estrutura!!!! colecao de campos

type usuario struct {
	nome  string
	idade int
}

type carro struct {
	roda string
	aro  int
}

func main() {
	fmt.Println("Arquivo struct")
	var nomeDaEstrutura usuario // var nomeQueVaiUsarParaChamar nomeDaEstrutura
	nomeDaEstrutura.nome = "Jhona"
	nomeDaEstrutura.idade = 18
	fmt.Println(nomeDaEstrutura)

	var teste carro
	teste.roda = "orbital"
	teste.aro = 17
	fmt.Println(teste.roda, teste.aro)

	testeUsarVariavel := carro{"de ferro", 18}
	fmt.Println(testeUsarVariavel)

	testeUsarVariavel2 := carro{aro: 18} // para acessar campo especifico da estrutura
	fmt.Println(testeUsarVariavel2)
}

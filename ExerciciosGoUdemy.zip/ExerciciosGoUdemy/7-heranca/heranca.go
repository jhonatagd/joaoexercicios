package main

import "fmt"

//Um conceito de >>programação orientada a objetos<< que uma classe/estrutura pode herdar
//atributos e comportamentos de uma classe pai. tipo raiz

type pessoa struct {
	nome      string
	sobrenome string
	idade     int
	altura    float64
}

type estudante struct {
	pessoa    // essa pessoa puxa ali da estrutura de pessoa
	curso     string
	faculdade string
}

type testaCarro struct {
	nome string
	ano  int
}

type acessorios struct {
	testaCarro // outro exemplo, esse carro puxa ali da estrutura de carro
	nomeDaCor  string
	Marca      string
}

func main() {
	fmt.Println("Herança")
	pessoaUm := pessoa{"Jhona", "Godoy", 18, 1.73}       // aqui a estrutura da pessoa
	estudanteUm := estudante{pessoaUm, "ADS", "Impacta"} // aqui do estudante, porem a pessoaUm complementa
	fmt.Println(estudanteUm)

	//carro := testaCarro{"Lancer", 2013} // usando a estrutura pai aqui, e colocando na variavel
	//fmt.Println(carro)

	var auxiliaPegarNaEstrutura2 testaCarro
	auxiliaPegarNaEstrutura2.ano = 2013
	auxiliaPegarNaEstrutura2.nome = "Lancer"
	fmt.Println(auxiliaPegarNaEstrutura2)

	var auxiliaPegarNaEstrutura acessorios
	auxiliaPegarNaEstrutura.nomeDaCor = "azul"
	auxiliaPegarNaEstrutura.Marca = "Mitsubsh"
	fmt.Println(auxiliaPegarNaEstrutura)
}

package main

import "fmt"

func main() {
	fmt.Println("Ponteiro é uma referencia de memoria, endereço de memoria onde está salvo")
	variavelUm := 10
	variavelDois := variavelUm
	fmt.Println(variavelUm, variavelDois)

	variavelDois++
	fmt.Println(variavelUm, variavelDois)

	var variavelTres int
	var ponteiro *int // endereco de memoria do ponteiro

	variavelTres = 100
	ponteiro = &variavelTres // & acessar o endereco de memoria, sem o & da problema, auxilia no return

	fmt.Println(variavelTres, *ponteiro)

	// nao usei nem nunca usei, porem já vi, entao alguns motivos do por que o ponteiro é bom:
	//Compartilhar dados entre partes do código.
	//Economia de memória com dados grandes.
	//Passagem por referência para modificar variáveis.

}

package main

import (
	"fmt"
)

//array é uma lista fixa e ordenada de elementos de mesmo tipo, entao se é xx vai ser todos x
//Slice é um array sem limite, é uma lista ainda com tudo do mesmo tipo, porem nao tem limite x
//Array é fixo, tamanho definido. Slice é flexível, tamanho dinâmico

func main() {
	fmt.Println("arrays e slices")

	var array1 [5]string // 0 1 2 3 4, conta assim os 5 começa do 0
	array1[0] = "posição 1"
	fmt.Println(array1)

	array2 := [5]string{"posição 1", "posição 2", "posição 3", "posição 4", "posição 5"}
	fmt.Println(array2)

	array3 := [...]int{1, 2, 3, 4, 5, 6, 7, 8}
	fmt.Println(array3)

	slice := []int{3, 5, 67, 9, 065, 4}
	fmt.Println(slice)

	slice2 := array2[1:3]
	fmt.Println(slice2)

	array2[1] = "posicao alterada"
	fmt.Println(slice2)
}
